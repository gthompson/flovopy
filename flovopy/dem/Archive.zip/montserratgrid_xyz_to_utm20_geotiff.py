from pathlib import Path
import re
import numpy as np
import pandas as pd
import rasterio
from rasterio.transform import from_origin
from rasterio.warp import calculate_default_transform, reproject, Resampling
from pyproj import CRS, Transformer

# --- Hardcoded paths ---
DEM_IN = Path("/Users/glennthompson/Dropbox/PROFESSIONAL/DATA/wadgeDEMs/trickster2025/Mont_10m.grd")
OUT_TIF = DEM_IN.with_name("DEM_10m_1999_xyz_UTM20N.tif")
POINTS_IN = Path("/Users/glennthompson/Dropbox/PROFESSIONAL/DATA/wadgeDEMs/trickster2025/PTS_ENH.TXT")
POINTS_OUT = POINTS_IN.with_name("PTS_ENH_WGS84_UTM20.csv")

# --- CRS definitions ---
# Montserrat Grid (TM on Clarke 1880) with Bursa–Wolf to WGS84
mont_crs = CRS.from_proj4(
    "+proj=tmerc +lat_0=0 +lon_0=-62 +k=0.9995 "
    "+x_0=400000 +y_0=0 "
    "+a=6378249.145 +b=6356514.86955 "
    "+towgs84=132.938,-128.285,-383.111,0,0,12.7996,9.9976"
)
wgs84 = CRS.from_epsg(4326)
utm20 = CRS.from_epsg(32620)

to_wgs84 = Transformer.from_crs(mont_crs, wgs84, always_xy=True)
to_utm20 = Transformer.from_crs(mont_crs, utm20, always_xy=True)

def write_tif_from_xyz(xyz_path: Path, out_path: Path):
    print(f"[DEM] Reading ASCII XYZ: {xyz_path}")
    xyz = np.loadtxt(xyz_path)
    if xyz.ndim != 2 or xyz.shape[1] < 3:
        raise RuntimeError("XYZ file must have 3 columns (x y z)")

    x, y, z = xyz[:, 0], xyz[:, 1], xyz[:, 2]
    xs = np.unique(x)
    ys = np.unique(y)

    if xs.size * ys.size != z.size:
        raise RuntimeError("XYZ grid is irregular or ragged; cannot reshape to 2D raster")

    dx = float(np.diff(xs).mean()) if xs.size > 1 else 1.0
    dy = float(np.diff(ys).mean()) if ys.size > 1 else 1.0

    nx, ny = xs.size, ys.size
    # Z should be arranged row-major with Y decreasing from top; reshape accordingly:
    Z = z.reshape((ny, nx))
    transform = from_origin(xs.min(), ys.max(), dx, dy)

    profile = {
        "driver": "GTiff",
        "height": ny,
        "width": nx,
        "count": 1,
        "dtype": "float32",
        "crs": mont_crs,            # stays in Montserrat CRS here
        "transform": transform,
        "compress": "deflate",
        "tiled": True,
        "blockxsize": 512,
        "blockysize": 512,
    }

    with rasterio.open(out_path, "w", **profile) as dst:
        dst.write(Z.astype("float32"), 1)

    print(f"[DEM] Wrote GeoTIFF (Montserrat CRS): {out_path}")
    with rasterio.open(out_path) as chk:
        arr = chk.read(1, masked=True)
        print(f"[DEM] Size={chk.width}x{chk.height} dtype={arr.dtype} min={arr.min()} max={arr.max()}")

def reproject_grd_to_utm(grd_path: Path, out_path: Path):
    print(f"[DEM] Reading Surfer GRD: {grd_path}")
    with rasterio.open(grd_path) as src:
        # Check we actually have a raster band
        if src.count < 1:
            raise RuntimeError("Input GRD has zero bands; cannot proceed.")

        src_crs = src.crs if src.crs is not None else mont_crs
        if src.crs is None:
            print("[DEM] No CRS in GRD; assigning Montserrat CRS.")

        src_transform = src.transform
        src_profile = src.profile.copy()
        src_nodata = src.nodata if src.nodata is not None else np.nan

        # Read the first band explicitly
        src_arr = src.read(1)  # shape (H, W)
        src_dtype = src_arr.dtype
        print(f"[DEM] src size={src.width}x{src.height} dtype={src_dtype} nodata={src_nodata}")

        # Compute target grid in UTM20
        dst_transform, dst_width, dst_height = calculate_default_transform(
            src_crs, utm20, src.width, src.height, *src.bounds
        )

        # Prepare an empty target array
        dst_arr = np.empty((dst_height, dst_width), dtype="float32")

        # Reproject into the array
        reproject(
            source=src_arr,
            destination=dst_arr,
            src_transform=src_transform,
            src_crs=src_crs,
            dst_transform=dst_transform,
            dst_crs=utm20,
            resampling=Resampling.bilinear,
            src_nodata=src_nodata,
            dst_nodata=src_nodata if np.isfinite(src_nodata) else None,
        )

        # Build output profile and write
        dst_profile = {
            "driver": "GTiff",
            "height": dst_height,
            "width": dst_width,
            "count": 1,
            "dtype": "float32",
            "crs": utm20,
            "transform": dst_transform,
            "nodata": src_nodata if np.isfinite(src_nodata) else None,
            "compress": "deflate",
            "tiled": True,
            "blockxsize": 512,
            "blockysize": 512,
        }

        with rasterio.open(out_path, "w", **dst_profile) as dst:
            dst.write(dst_arr, 1)

    print(f"[DEM] Wrote GeoTIFF (UTM20N): {out_path}")
    with rasterio.open(out_path) as chk:
        arr = chk.read(1, masked=True)
        print(f"[DEM] dst size={chk.width}x{chk.height} dtype={arr.dtype} min={arr.min()} max={arr.max()}")

# --- DEM branch chooser ---
suffix = DEM_IN.suffix.lower()
if suffix == ".asc":
    write_tif_from_xyz(DEM_IN, OUT_TIF)
elif suffix == ".grd":
    reproject_grd_to_utm(DEM_IN, OUT_TIF)
else:
    raise SystemExit(f"Unsupported DEM format: {DEM_IN.suffix}")

# --- Points: robust parser (E N H Site-with-spaces) + transforms ---
print(f"[POINTS] Reading {POINTS_IN}")

rows = []
num_re = r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)'  # float/int pattern
line_re = re.compile(rf'^\s*({num_re})\s+({num_re})\s+({num_re})\s+(.*\S)\s*$')

with open(POINTS_IN, "r", encoding="utf-8", errors="ignore") as f:
    for ln, raw in enumerate(f, start=1):
        s = raw.strip()
        if not s or s.startswith("#"):
            continue
        # Skip header row like "E N H Site"
        if ln == 1 and re.search(r'\bE\b', s) and re.search(r'\bN\b', s) and re.search(r'\bH\b', s):
            continue
        m = line_re.match(s)
        if not m:
            print(f"[POINTS:WARN] Skipping unparsable line {ln}: {s}")
            continue
        e, n, h, site = m.groups()
        try:
            rows.append({"E": float(e), "N": float(n), "H": float(h), "Site": site.strip()})
        except ValueError:
            print(f"[POINTS:WARN] Numeric parse failed on line {ln}: {s}")

if rows:
    df = pd.DataFrame(rows)
    # Mont->WGS84 and Mont->UTM20
    lons, lats = to_wgs84.transform(df["E"].values, df["N"].values)
    utm_e, utm_n = to_utm20.transform(df["E"].values, df["N"].values)

    df_out = pd.DataFrame({
        "Site": df["Site"],
        "E_mont": df["E"],
        "N_mont": df["N"],
        "H_m": df["H"],
        "lon": lons,
        "lat": lats,
        "UTM20_E": utm_e,
        "UTM20_N": utm_n,
    })
    df_out.to_csv(POINTS_OUT, index=False)
    print(f"[POINTS] Wrote transformed station list: {POINTS_OUT}")
else:
    print("[POINTS] No valid rows parsed; nothing written.")